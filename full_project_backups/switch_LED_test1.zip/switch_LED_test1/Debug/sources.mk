################################################################################
# Automatically-generated file. Do not edit!
################################################################################

ASM_SRCS := 
C_SRCS := 
OBJ_SRCS := 
O_SRCS := 
S_SRCS := 
S_UPPER_SRCS := 
C_DEPS := 
EXECUTABLES := 
OBJS := 

# Every subdirectory with source files must be described here
SUBDIRS := \
board \
component/uart \
device \
drivers \
source \
startup \
utilities/debug_console_lite \
utilities \
utilities/str \

